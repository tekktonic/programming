#include "SDL.h"

int main(int argc, char** argv)  {
  int width = 640;
  int height = 480;
  
  if (SDL_Init(SDL_INIT_VIDEO) != 0)  {
  }
  atexit(SDL_Quit);
  
  SDL_Window* window = SDL_CreateWindow(
    "Example", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 
    width, height, SDL_WINDOW_RESIZABLE
  );
  Uint32 windowID = SDL_GetWindowID(window);
  
  while (1)  {
    SDL_Event event;
    while (SDL_PollEvent(&event))  {
      switch (event.type)  {
        
        case SDL_WINDOWEVENT:  {
          if (event.window.windowID == windowID)  {
            switch (event.window.event)  {
              
              case SDL_WINDOWEVENT_SIZE_CHANGED:  {
                width = event.window.data1;
                height = event.window.data2;
                break;
              }
              
              case SDL_WINDOWEVENT_CLOSE:  {
                event.type = SDL_QUIT;
                SDL_PushEvent(&event);
                break;
              }
              
            }
          }
          break;
        }
        
        case SDL_QUIT:  {
          return 0;
        }
        
        /* ... */
        
      }
    }
    
    /* ... */
    
  }
  printf("probably exiting gracefully!\n");
}
