#ifndef GLOBAL_H
#define GLOBAL_H
#include <SDL.h>

SDL_Renderer *renderer;
#endif
