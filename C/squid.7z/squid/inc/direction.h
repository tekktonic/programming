#ifndef DIRECTION_H
#define DIRECTION_H
typedef enum
{
    D_UP,
    D_DOWN,
    D_LEFT,
    D_RIGHT
} Direction;

#endif
