#ifndef SPRITE_H
#define SPRITE_H
#include <stdlib.h>
#include <SDL.h>
#include <math.h>
#include <chipmunk.h>

#include "resourcemanager.h"

typedef struct
{
    SDL_Texture *image;
    cpVect position;
    int w, h;

    cpBody *body;

    cpShape **shape;
} Sprite;

Sprite new_Sprite(ResourceManager rm, const char *image);
#endif
