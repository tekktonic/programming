#ifndef ENTITY_H
#define ENTITY_H
#include "dtype.h"

#endif
