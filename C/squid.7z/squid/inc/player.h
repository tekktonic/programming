#ifndef PLAYER_H
#define PLAYER_H
#include <math.h>
#include <stdbool.h>

#include <SDL.h>
#include <chipmunk.h>

#include "sprite.h"
#include "direction.h"
#include "window.h"
#include "entity.h"
#include "event.h"
#include "entity_types.h"

#include "tonic.h"

Entity new_Player(ResourceManager rm, Room room, short x, short y);

void Player_update(Entity p);

void Player_draw(Entity p, SDL_Renderer *renderer, Window window);

void Player_move(Player p, Direction d);

void Player_react(Entity p);
#endif
