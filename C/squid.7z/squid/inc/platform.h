#ifndef PLATFORM_H
#define PLATFORM_H

#include <SDL.h>
#include <chipmunk.h>

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "sprite.h"
#include "window.h"
#include "entity.h"
#include "entity_types.h"
#include "tonic.h"

Entity new_Platform(ResourceManager rm, Room room, short x, short y, double rotation);
// platform is just a sprite
void Platform_react(Entity entity);
void Platform_update(Entity entity);
void Platform_draw(Entity entity, SDL_Renderer *renderer, Window window);

#endif
