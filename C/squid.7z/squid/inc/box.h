#ifndef PLATFORM_H
#define PLATFORM_H

#include <SDL.h>
#include <chipmunk.h>

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "sprite.h"
#include "window.h"
#include "entity.h"
#include "entity_types.h"

Entity new_Box(ResourceManager rm, Room room, short x, short y, double rotation);
// box is just a sprite
void Box_react(Entity entity);
void Box_update(Entity entity);
void Box_draw(Entity entity, SDL_Renderer *renderer, Window window);

#endif
