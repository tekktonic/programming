#ifndef ERR_H
#define ERR_H

#define ENORMAL 0
#define ESDL 1
void *Maybe(void *thing, char sdl);
#endif
