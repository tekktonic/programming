#ifndef ENTITY_TYPES_H
#define ENTITY_TYPES_H
#include <SDL.h>
#include <stdbool.h>

#include "sprite.h"
#include "window.h"
struct Room_s;

struct Entity_s
{
    void (*react)(struct Entity_s *entity);
    void (*update)(struct Entity_s *entity);
    void (*draw)(struct Entity_s *entity, SDL_Renderer *renderer, Window window);
    Queue events;
    cpBody *body;

    struct Room_s *room;
    void *data;
};

typedef struct Entity_s *Entity;struct Room_s
{
    List entities;
    Sprite background;
    SDL_Renderer *renderer;
    Window window;
    int width, height;
    int sox, soy; // screen x and y offsets from the world
    Entity cameraFocus;
    Queue toReact;

    cpVect gravity;
    cpSpace *space;
};
typedef struct Room_s *Room;

struct Player_s
{
    Sprite sprite;

    Sprite chargeBar;
    Room room;
    float charge, speed;
    bool charging;
};
typedef struct Player_s *Player;


#endif
