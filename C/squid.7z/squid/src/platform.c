#include "platform.h"

Entity new_Platform(ResourceManager rm, Room room, short x, short y, double rotation)
{
    Entity ret = malloc(sizeof(struct Entity_s));
    assert(ret);
    // this isn't a mistake. ret->data is a pointer and can't hold a full Sprite
    ret->data = malloc(sizeof(Sprite));
    Sprite tmp = new_Sprite(rm, "platform.png");

    ret->body = cpBodyNewStatic();
    cpBodySetPos(ret->body, cpv(x, y));
    tmp.shape = malloc(sizeof(cpShape*));
    tmp.shape[0] = cpBoxShapeNew(ret->body, tmp.w, tmp.h);
    cpShapeSetFriction(tmp.shape[0], 1);

    cpBodySetAngle(ret->body, rotation);
    cpSpaceAddShape(room->space, tmp.shape[0]);
    tmp.shape[1] = NULL;

    memcpy (ret->data, &tmp, sizeof(Sprite));
    assert(ret->data);

    ret->room = room;
    ret->react = Platform_react;
    ret->update = Platform_update;
    ret->draw = Platform_draw;

    return ret;
}

void Platform_react(Entity entity)
{
    return;
}

void Platform_update(Entity entity)
{
    Sprite sprite = *(Sprite*)entity->data;
    cpBodyApplyForce(entity->body, cpv(0, 1), cpv(-64, 0));
    return;
}

void Platform_draw(Entity entity, SDL_Renderer *renderer, Window window)
{
    Sprite sprite = *(Sprite*)entity->data;
    cpVect position = cpBodyGetPos(entity->body);
    SDL_Rect rect = {position.x + 400 - (sprite.w / 2) + entity->room->sox, (-position.y + 300 - (sprite.h / 2)), sprite.w, sprite.h};
    SDL_Rect scale = Window_Scale(window, &rect);
    SDL_RenderCopyEx(renderer, sprite.image, NULL, &scale, rtod(cpBodyGetAngle(entity->body)), NULL, SDL_FLIP_NONE);
}
