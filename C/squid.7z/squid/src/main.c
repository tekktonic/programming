#include <stdbool.h>
#include <SDL.h>

#include "err.h"
#include "dtype.h"
#include "resourcemanager.h"
#include "sprite.h"
#include "player.h"
#include "platform.h"
#include "globals.h"
#include "window.h"
#include "room.h"
#include "event.h"

#include "direction.h"


int main(void)
{
    bool running = true;
    SDL_Event e;
    // I could do SDL_CreateWindowAndRenderer, but then I lose the ability to use Maybes

    Window window;
    ResourceManager rm = Maybe(new_ResourceManager(), ENORMAL);


    SDL_Init(SDL_INIT_VIDEO|SDL_INIT_EVENTS);
    atexit(&SDL_Quit);

    window = new_Window(Maybe(SDL_CreateWindow("Squid", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 800, 600, SDL_WINDOW_RESIZABLE), ESDL));
    renderer = Maybe(SDL_CreateRenderer(window->window, -1, SDL_RENDERER_ACCELERATED), ESDL);
    Room room = Maybe(new_Room(renderer, rm, window, new_Sprite(rm, "bg.png"), "resources/maps/1.json"), ENORMAL);

    Entity player = room->entities->car;

    while (running)
    {
	const uint8_t *keystate;
	while (SDL_PollEvent(&e))
	{
	    switch (e.type) {
	    case SDL_QUIT:
		running = false;
		break;
	    case SDL_WINDOWEVENT:

		if (e.window.event != SDL_WINDOWEVENT_RESIZED)
		{
		    Window_ResizedCB(window);
		}
		break;
	    }
	}

	keystate  = SDL_GetKeyboardState(NULL);
	if (keystate[SDL_SCANCODE_RIGHT])
	{
	    struct Event_s *event = malloc(sizeof(struct Event_s));
	    event->type = EVENT_PRESS;
	    event->data = D_RIGHT;
	    List_enqueue(player->events, event);
	    if (!List_contains(room->toReact, player))
		List_enqueue(room->toReact, player);
	}

	if (keystate[SDL_SCANCODE_LEFT])
	{
	    struct Event_s *event = malloc(sizeof(struct Event_s));
	    event->type = EVENT_PRESS;
	    event->data = D_LEFT;
	    List_enqueue(player->events, event);
	    if (!List_contains(room->toReact, player))
		List_enqueue(room->toReact, player);

	}

	if (keystate[SDL_SCANCODE_UP])
	{
	    struct Event_s *event = malloc(sizeof(struct Event_s));
	    event->type = EVENT_PRESS;
	    event->data = D_UP;
	    List_enqueue(player->events, event);
	    if (!List_contains(room->toReact, player))
		List_enqueue(room->toReact, player);

	}
	else
	{
	    struct Event_s *event = malloc(sizeof(struct Event_s));
	    event->type = EVENT_RELEASE;
	    event->data = D_UP;
	    List_enqueue(player->events, event);
	    if (!List_contains(room->toReact, player))
		List_enqueue(room->toReact, player);

	}


	Room_react(room);
	Room_draw(room);

	SDL_RenderPresent(renderer);
    
	SDL_Delay(1000 / 60);

	Room_update(room);
    }
    SDL_DestroyWindow(window->window);
    return 0;
}
