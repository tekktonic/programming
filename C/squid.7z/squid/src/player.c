#include "player.h"

Entity new_Player(ResourceManager rm, Room room, short x, short y)
{
    Entity ret = malloc(sizeof(struct Entity_s));
    ret->data = malloc(sizeof(struct Player_s));
    Player player = (Player)ret->data;

    if (ret)
    {
	player->speed = 0.0;
	player->sprite = new_Sprite(rm, "squid-player.png");
	ret->body = cpSpaceAddBody(room->space, cpBodyNew(0.01, 10));
	player->room = room;
	player->sprite.shape = malloc(sizeof(cpShape*)*2);
	const cpVect topVert[] = {cpv(0, 32), cpv(32, 2), cpv(-32, 2)};
	const cpVect bodyVert[] = {cpv(16, 2), cpv(16, -29), cpv(-16, -29), cpv(-16, 2)};
	player->sprite.shape[0] = cpPolyShapeNew(ret->body, 3, topVert, cpv(0, 0));

	cpShapeSetFriction(player->sprite.shape[0], 0.7);
	cpShapeSetElasticity(player->sprite.shape[0], 0.0);
	cpSpaceAddShape(room->space, player->sprite.shape[0]);

	player->sprite.shape[1] = cpPolyShapeNew(ret->body, 3, bodyVert, cpv(0, 0));
	cpShapeSetFriction(player->sprite.shape[1], 0.7);
	cpShapeSetElasticity(player->sprite.shape[1], 0.0);	
	cpSpaceAddShape(room->space, player->sprite.shape[1]);

	cpBodySetPos(ret->body, cpv(x, y));

	cpBodySetVelLimit(ret->body, 600.0);

	ret->update = Player_update;
	ret->draw = Player_draw;
	ret->react = Player_react;
	ret->events = new_List(0);
    }

    room->cameraFocus = ret;
    return ret; // Maybe catches the NULL for us
}

void Player_update(Entity p)
{
    Player player = p->data;

    cpFloat angle = cpBodyGetAngle(p->body);

    printf("%d %f\n", player->charging, player->charge);


    if (!player->charging)
    {
	player->speed = (player->speed - 0.1 > 0 ? player->speed - 0.1 : 0.0);
	cpBodySetForce(p->body, cpv(sin(angle) * (player->speed)/* * 5*/, cos(angle) * (player->speed)/* * 5 */));
    }
}

void Player_draw(Entity p, SDL_Renderer *renderer, Window window)
{
    Player player = p->data;
    cpVect position = cpBodyGetPos(p->body);
    SDL_Rect rect = {position.x + 400 - (player->sprite.w / 2) + player->room->sox, (-position.y + 300 - (player->sprite.h / 2)) + player->room->soy, player->sprite.w, player->sprite.h};
    SDL_Rect scale = Window_Scale(window, &rect);
    cpFloat angle = cpBodyGetAngle(p->body);
    SDL_RenderCopyEx(renderer, player->sprite.image, NULL, &scale, rtod(angle), NULL, SDL_FLIP_NONE); 
}

void Player_react(Entity p)
{
    Queue events = p->events;
    Player player = p->data;
    cpFloat angle = cpBodyGetAngle(p->body);
    while (events->cdr)
    {
	struct Event_s *event = (struct Event_s*)List_dequeue(p->events);
	switch (event->type)
	{
	case EVENT_PRESS:

	    switch ((Direction)event->data)
	    {
	    case D_RIGHT:
		cpBodySetAngle(p->body, cpBodyGetAngle(p->body) + 0.1);

		break;
	    case D_LEFT:
		cpBodySetAngle(p->body, cpBodyGetAngle(p->body) - 0.1);
		break;
	    case D_UP:
		player->charging = true;
		player->charge = (player->charge + 1 < 20.0 ? player->charge + 1 : 20.0);
		break;
	    }
	break;

	case EVENT_RELEASE:
	    switch ((Direction)event->data)
		{
		default:
		    player->charging = false;
		    player->speed += player->charge;
		    player->charge = 0;
		}
	}

    end:
	free(event);
    }
}
