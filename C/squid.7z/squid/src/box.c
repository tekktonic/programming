#include "box.h"

Entity new_Box(ResourceManager rm, Room room, short x, short y, double rotation)
{
    Entity ret = malloc(sizeof(struct Entity_s));
    assert(ret);
    // this isn't a mistake. ret->data is a pointer and can't hold a full Sprite
    ret->data = malloc(sizeof(Sprite));

    ret->body = cpSpaceAddBody(room->space, cpBodyNew(50, 100));//cpMomentForBox(0.0, 64, 64)));
    cpBodySetPos(ret->body, cpv(x, y));

    Sprite tmp = new_Sprite(rm, "box.png");

    tmp.shape = malloc(sizeof(cpShape*));
    tmp.shape[0] = cpBoxShapeNew(tmp.body, tmp.w, tmp.h);
    cpShapeSetFriction(tmp.shape[0], 1);

    cpBodySetAngle(ret->body, rotation);
    cpSpaceAddShape(room->space, tmp.shape[0]);
    tmp.shape[1] = NULL;

    memcpy (ret->data, &tmp, sizeof(Sprite));
    assert(ret->data);

    ret->room = room;
    ret->react = Box_react;
    ret->update = Box_update;
    ret->draw = Box_draw;

    return ret;
}

void Box_react(Entity entity)
{
    return;
}

void Box_update(Entity entity)
{
    return;
}

void Box_draw(Entity entity, SDL_Renderer *renderer, Window window)
{
    Sprite sprite = *(Sprite*)entity->data;
    cpVect position = cpBodyGetPos(entity->body);
    SDL_Rect rect = {position.x + 400 - (sprite.w / 2), (-position.y + 300 - (sprite.h / 2)) + entity->room->soy, sprite.w, sprite.h};
    SDL_Rect scale = Window_Scale(window, &rect);
    SDL_RenderCopyEx(renderer, sprite.image, NULL, &scale, rtod(cpBodyGetAngle(entity->body)), NULL, SDL_FLIP_NONE);
}
