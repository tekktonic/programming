#include "tonic.h"

double rtod(double radians)
{
    return radians * 180 / M_PI;
}
